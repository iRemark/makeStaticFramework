//
//  ViewController.m
//  testDemo
//
//  Created by lc-macbook pro on 2017/7/25.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "ViewController.h"
#import <StaticFramework/StaticFramework.h>


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    NSString *string = @"https://baike.baidu.com/api/openapi/BaikeLemmaCardApi?scope=103&format=json&appid=379020&bk_key=%E9%93%B6%E9%AD%82&bk_length=600";
    AFHTTPSessionManager *session = [AFHTTPSessionManager manager];
    
    
    session.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    session.securityPolicy.allowInvalidCertificates = YES;
    [session.securityPolicy setValidatesDomainName:NO];
    
    [session GET:string parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
        
    }success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        
        NSLog(@"返回结果：%@",responseObject);
        
    }failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull   error) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        
    }];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
