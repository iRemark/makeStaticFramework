//
//  StaticFramework.h
//  StaticFramework
//
//  Created by lc-macbook pro on 2017/7/25.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for StaticFramework.
FOUNDATION_EXPORT double StaticFrameworkVersionNumber;

//! Project version string for StaticFramework.
FOUNDATION_EXPORT const unsigned char StaticFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StaticFramework/PublicHeader.h>

#import "AFNetworking.h"
